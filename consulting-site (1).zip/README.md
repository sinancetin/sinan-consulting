# Stratejik Satış & E‑Ticaret Danışmanlığı — Tek Sayfa Site

## Hızlı Başlangıç
1) Bağımlılıkları yükleyin:
```bash
npm i
npm run dev
```
2) Tarayıcıdan açın: http://localhost:3000

## Deploy (Vercel önerilir)
- Vercel hesabı açın ve bu klasörü içeren GitHub reposunu bağlayın.
- "Import Project" → otomatik build & deploy.
- Ortam değişkeni gerekmiyor.

## Düzenlemeler
- `app/page.tsx` içinde e‑posta ve telefonu değiştirin.
- Form eklemek için Formspree gibi servisleri kullanabilirsiniz.

## Teknolojiler
- Next.js 14 (App Router)
- Tailwind CSS
